# CodeΩ V6 · Système Oméga Universel

[![Live](https://img.shields.io/badge/Live-GitHub%20Pages-blue)](https://yannick1248.github.io/CodeOmega-V6/)
[![Version](https://img.shields.io/badge/version-6.0-purple)](https://github.com/yannick1248/CodeOmega-V6)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)

**🌐 Live App → https://yannick1248.github.io/CodeOmega-V6/**

Noyau universel de compression intelligente — code multi-langage + texte naturel français.

## Structure

```
CodeOmega-V6/
├── index.html                   ← Redirect auto
├── dist/
│   └── Code-Omega-V6.html       ← App principale (28KB)
├── corpus/
│   ├── python-test.py
│   └── fr-text.txt
├── .github/workflows/
│   └── deploy.yml               ← GitHub Pages auto-deploy
├── README.md
├── CHANGELOG.md
└── LICENSE
```

## Deploy 2 min (sans CLI)

1. **Créer repo** → https://github.com/new → nommer `CodeOmega-V6` (Public)
2. **Upload** → "Add file" → "Upload files" → glisser tout le contenu du ZIP
3. **GitHub Pages** → Settings → Pages → Source: GitHub Actions
4. **URL live** : https://yannick1248.github.io/CodeOmega-V6/

## Test iPhone

1. Ouvrir URL dans Safari
2. 📤 Partager → "Sur l'écran d'accueil"
3. Icône native ✓

## D.Y. Roth · 2026 · U·Ω Nil Obstat
