def process(items, active=True):
    for i in range(0, len(items)):
        if active == True: pass
