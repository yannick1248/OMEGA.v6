# CHANGELOG

## v6.0 (2026-04-06)
- Production-ready web app
- GitHub Pages auto-deploy
- Compression texte naturel FR
- 21 Axiomes Oméga intégrés
- Quantum nodes + Dijkstra
- Auto-Forge COMMIT/ROLLBACK
- Responsive iPhone→4K
